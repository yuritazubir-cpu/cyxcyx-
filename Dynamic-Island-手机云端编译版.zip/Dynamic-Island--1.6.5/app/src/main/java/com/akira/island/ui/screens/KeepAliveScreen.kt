package com.akira.island.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.Security
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import com.akira.island.core.tr
import com.akira.island.data.SettingsRepo
import com.akira.island.service.KeepAliveService
import com.akira.island.ui.Group
import com.akira.island.ui.GroupItem
import com.akira.island.ui.GroupToggle
import com.akira.island.ui.Page
import com.akira.island.ui.Perms
import com.akira.island.ui.Perms.Vendor
import com.akira.island.ui.Pos
import com.akira.island.ui.Screen
import com.akira.island.ui.SectionHeader
import com.akira.island.ui.Tile

/**
 * «Чтобы остров не закрывался»: Xiaomi (HyperOS), Oppo, realme, OnePlus (ColorOS), Samsung и другие сами
 * выгружают приложения в фоне — особенно если смахнуть их из недавних. Здесь кнопки прямо в нужные
 * настройки этой прошивки и подсказка, как закрепить остров в недавних.
 */
@Composable
fun KeepAliveScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val vendor = Perms.vendor()
    val (battery, _) = rememberOnResume { Perms.batteryUnrestricted(context) }
    val s by SettingsRepo.state.collectAsState()

    Page(tr("Чтобы остров не закрывался", "Keep the island running", "保持灵动岛运行"), onBack,
        subtitle = tr("Прошивка телефона может выгружать остров в фоне — тогда он пропадает, пока его не включить снова",
            "Your phone's firmware may stop the island in the background — then it disappears until you turn it on again",
            "手机系统可能会在后台停止灵动岛——停止后它会消失，直到您再次开启")) {
        // Процесс со службой на переднем плане Android не закрывает, когда приложение смахивают из недавних
        GroupToggle(
            Pos.Single, Icons.Rounded.PushPin, tr("Не выгружать остров", "Keep the island loaded", "保持灵动岛常驻"),
            tr("Остров не пропадёт, даже если смахнуть приложение из недавних. Android может показать тихое уведомление",
                "The island stays even if you swipe the app away from recent apps. Android may show a quiet notification",
                "即使您在最近任务中划掉应用，灵动岛也会保留。Android 可能会显示一条静默通知"),
            s.keepAlive, color = Tile.Purple,
        ) { v ->
            SettingsRepo.update { copy(keepAlive = v) }
            KeepAliveService.sync(context)
        }

        Group {
            GroupItem(
                if (Perms.hasAutostart()) Pos.First else Pos.Single, Icons.Rounded.BatteryChargingFull,
                tr("Батарея без ограничений", "Unrestricted battery", "电池无限制"),
                batteryHint(vendor), onClick = { Perms.openBattery(context) }, color = Tile.Green,
            ) { Status(battery) }
            if (Perms.hasAutostart()) {
                GroupItem(
                    Pos.Last, Icons.Rounded.RocketLaunch, tr("Автозапуск", "Autostart", "自启动"),
                    tr("Включите для «Динамического острова» — тогда он запустится сам после перезагрузки и закрытия",
                        "Turn it on for Dynamic Island — then it starts by itself after a reboot or being closed",
                        "为灵动岛开启——这样它在重启或被关闭后会自动启动"),
                    onClick = { Perms.openAutostart(context) }, color = Tile.Orange,
                ) { Arrow() }
            }
        }

        SectionHeader(tr("Закрепите в недавних", "Lock it in recent apps", "在最近任务中锁定"))
        InfoText(lockHint(vendor))

        SectionHeader(tr("Если остров всё равно пропал", "If the island still disappears", "如果灵动岛仍然消失"))
        Group {
            GroupItem(
                Pos.First, Icons.Rounded.Lock, tr("Спец. возможности", "Accessibility", "无障碍"),
                tr("Выключите и снова включите службу «Динамический остров»", "Turn the Dynamic Island service off and on again", "关闭灵动岛服务再重新开启"),
                onClick = { Perms.openAccessibility(context) }, color = Tile.Blue,
            ) { Arrow() }
            AppDetailsItem(Pos.Last)
        }
    }
}

/** Пункт «Чтобы остров не закрывался» — в «Разрешениях» и «О приложении». */
@Composable
internal fun KeepAliveItem(pos: Pos, open: (Screen) -> Unit) {
    GroupItem(pos, Icons.Rounded.BatteryChargingFull, tr("Чтобы остров не закрывался", "Keep the island running", "保持灵动岛运行"),
        tr("Батарея, автозапуск и закрепление в недавних", "Battery, autostart and locking in recent apps", "电池、自启动和在最近任务中锁定"),
        onClick = { open(Screen.KEEPALIVE) }, color = Tile.Green) { Arrow() }
}

/** «О приложении» в настройках Android: ограниченные настройки, разрешения, батарея. */
@Composable
internal fun AppDetailsItem(pos: Pos) {
    val context = LocalContext.current
    GroupItem(pos, Icons.Rounded.Security, tr("О приложении в системе", "App info in Android", "Android 应用信息"),
        tr("Ограниченные настройки, разрешения, батарея", "Restricted settings, permissions, battery", "受限制的设置、权限、电池"),
        onClick = { Perms.openAppDetails(context) }, color = Tile.Gray)
}

private fun batteryHint(v: Vendor): String = when (v) {
    Vendor.XIAOMI -> tr("«Контроль активности» или «Экономия энергии» → «Нет ограничений»",
        "Battery saver or “Activity control” → “No restrictions”",
        "省电模式或“活动控制”→“无限制”")
    Vendor.SAMSUNG -> tr("«Батарея» → «Без ограничений», и уберите остров из «Приложений в спящем режиме»",
        "Battery → Unrestricted, and remove the island from Sleeping apps",
        "电池 → 无限制，并将灵动岛从“休眠应用”中移除")
    Vendor.OPPO -> tr("«Использование батареи» → разрешите работу в фоне", "Battery usage → allow background activity", "电池使用情况 → 允许后台活动")
    else -> tr("Найдите «Динамический остров» и выберите «Не оптимизировать» или «Без ограничений»",
        "Find Dynamic Island and choose “Don't optimize” or “Unrestricted”",
        "找到灵动岛，选择“不优化”或“无限制”")
}

private fun lockHint(v: Vendor): String = when (v) {
    Vendor.XIAOMI -> tr(
        "Откройте недавние приложения, зажмите карточку «Динамический остров» и нажмите на замок. " +
            "Закреплённое приложение HyperOS и MIUI не закрывают, даже когда вы чистите недавние.",
        "Open recent apps, long-press the Dynamic Island card and tap the lock. HyperOS and MIUI don't close a " +
            "locked app, even when you clear recent apps.",
        "打开最近任务，长按灵动岛卡片并点击锁图标。即使您清除最近任务，HyperOS 和 MIUI 也不会关闭已锁定的应用。",
    )
    Vendor.OPPO -> tr(
        "Откройте недавние приложения, нажмите «⋮» над карточкой «Динамический остров» (или потяните её вниз) " +
            "и выберите «Заблокировать».",
        "Open recent apps, tap “⋮” above the Dynamic Island card (or pull it down) and choose “Lock”.",
        "打开最近任务，点击灵动岛卡片上方的“⋮”（或将其下拉），选择“锁定”。",
    )
    Vendor.SAMSUNG -> tr(
        "Откройте недавние приложения, нажмите на значок над карточкой «Динамический остров» и выберите «Не закрывать».",
        "Open recent apps, tap the icon above the Dynamic Island card and choose “Keep open”.",
        "打开最近任务，点击灵动岛卡片上方的图标，选择“保持打开”。",
    )
    else -> tr(
        "Откройте недавние приложения и потяните карточку «Динамический остров» вниз или зажмите её — " +
            "появится замок. Закреплённое приложение не закрывается, когда вы чистите недавние.",
        "Open recent apps and pull the Dynamic Island card down or long-press it — a lock appears. A locked app " +
            "isn't closed when you clear recent apps.",
        "打开最近任务，将灵动岛卡片下拉或长按——会出现一把锁。清除最近任务时，已锁定的应用不会被关闭。",
    )
}
