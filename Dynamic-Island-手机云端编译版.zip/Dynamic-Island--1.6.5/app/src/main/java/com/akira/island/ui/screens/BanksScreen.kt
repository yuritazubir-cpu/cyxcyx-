package com.akira.island.ui.screens

import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Icon
import android.os.Build
import android.widget.Toast
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.AddBox
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import com.akira.island.R
import com.akira.island.core.Controls
import com.akira.island.core.IslandBus
import com.akira.island.core.tr
import com.akira.island.service.IslandTile
import com.akira.island.ui.Group
import com.akira.island.ui.GroupItem
import com.akira.island.ui.Page
import com.akira.island.ui.Perms
import com.akira.island.ui.Pos
import com.akira.island.ui.Screen
import com.akira.island.ui.SectionHeader
import com.akira.island.ui.Tile

/**
 * «Банк не пускает»: многие банки (K PLUS, GCash и другие) не открываются, пока включена служба спец. возможностей
 * не из Play Маркета, — так они защищаются от мошенников. Остров тут ни при чём, и обойти проверку изнутри него
 * нельзя: только выключить остров на время. Здесь — как сделать это одним нажатием и включить обратно.
 */
@Composable
fun BanksScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val running by IslandBus.serviceRunning.collectAsState()

    Page(tr("Банк не пускает", "Bank app won't open", "银行应用打不开"), onBack,
        subtitle = tr("Банк пишет, что обнаружено стороннее приложение или спец. возможности?",
            "Your bank says it detected a third-party app or accessibility service?",
            "银行提示检测到第三方应用或无障碍服务？")) {
        InfoText(
            tr(
                "Так банки защищаются от мошенников: пока включена любая служба спец. возможностей не из Play Маркета, " +
                    "они не пускают. Остров ничего не читает в банке, но проверку обойти нельзя — только выключить " +
                    "остров на время. Проще всего — плиткой в шторке: нажали — остров выключился, можно в банк; " +
                    "нажали ещё раз — включаете обратно.",
                "Banks do this to protect against fraud: while any accessibility service not from Google Play is on, " +
                    "they won't let you in. The island reads nothing in your bank, but there's no way around the check — " +
                    "only turning the island off for a while. The easiest way is a tile in quick settings: tap it — the " +
                    "island turns off and you can use the bank; tap it again to turn the island back on.",
                "银行这样做是为了防范诈骗：只要开启了任何非 Google Play 来源的无障碍服务，银行应用就不让您进入。灵动岛不会读取银行应用中的任何内容，但这项检查无法绕过——只能暂时关闭灵动岛。最简单的方法是使用快捷设置里的磁贴：点一下——灵动岛关闭，您就可以使用银行应用；再点一下——重新开启灵动岛。",
            ),
        )
        Group {
            val tileAsk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
            if (tileAsk) {
                GroupItem(
                    Pos.First, Icons.Rounded.AddBox, tr("Добавить плитку «Остров»", "Add the Island tile", "添加“灵动岛”磁贴"),
                    tr("В шторку быстрых настроек — одно нажатие", "To quick settings — one tap", "添加到快捷设置——点一下即可"),
                    color = Tile.Blue, onClick = { addTile(context) },
                ) { Arrow() }
            }
            GroupItem(
                if (tileAsk) Pos.Middle else Pos.First, Icons.Rounded.PowerSettingsNew, tr("Выключить остров сейчас", "Turn the island off now", "立即关闭灵动岛"),
                if (running) tr("Включить обратно — в спец. возможностях или плиткой", "Turn it back on in Accessibility or with the tile", "之后可在无障碍设置中或通过磁贴重新开启")
                else tr("Остров уже выключен", "The island is already off", "灵动岛已关闭"),
                color = Tile.Orange, onClick = { if (running) Controls.turnOffIsland() },
            )
            GroupItem(
                Pos.Last, Icons.Rounded.Lock, tr("Включить остров", "Turn the island on", "开启灵动岛"),
                tr("Откроются спец. возможности — «Динамический остров» → включить", "Opens Accessibility — Dynamic Island → turn on", "打开无障碍设置 — 灵动岛 → 开启"),
                color = Tile.Green, onClick = { Perms.openAccessibility(context) },
            ) { Arrow() }
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            SectionHeader(tr("Плитка в шторке", "The quick settings tile", "快捷设置磁贴"))
            InfoText(
                tr("Откройте шторку целиком, нажмите карандаш и перетащите плитку «Остров» к остальным.",
                    "Open quick settings fully, tap the pencil and drag the Island tile to the others.",
                    "完全展开快捷设置，点击铅笔图标，把“灵动岛”磁贴拖到其他磁贴旁。"),
            )
        }
    }
}

/** Android 13+: система сама спрашивает, добавить ли плитку острова в шторку. */
private fun addTile(context: Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
    val bar = context.getSystemService(StatusBarManager::class.java) ?: return
    runCatching {
        bar.requestAddTileService(
            ComponentName(context, IslandTile::class.java), context.getString(R.string.tile_label),
            Icon.createWithResource(context, R.drawable.ic_tab_island), context.mainExecutor,
        ) { result ->
            if (result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED) {
                Toast.makeText(context, tr("Плитка уже в шторке", "The tile is already in quick settings", "磁贴已在快捷设置中"), Toast.LENGTH_SHORT).show()
            }
        }
    }
}

/** Пункт «Банк не пускает» — на главной, рядом с «Чтобы остров не закрывался». */
@Composable
internal fun BanksItem(pos: Pos, open: (Screen) -> Unit) {
    GroupItem(pos, Icons.Rounded.AccountBalance, tr("Банк не пускает", "Bank app won't open", "银行应用打不开"),
        tr("Плитка, чтобы выключать остров на время", "A tile to turn the island off for a while", "用于暂时关闭灵动岛的磁贴"),
        onClick = { open(Screen.BANKS) }, color = Tile.Indigo) { Arrow() }
}
