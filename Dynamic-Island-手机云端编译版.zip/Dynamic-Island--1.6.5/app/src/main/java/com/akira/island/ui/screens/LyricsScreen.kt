package com.akira.island.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.akira.island.core.tr
import com.akira.island.data.SettingsRepo
import com.akira.island.ui.Group
import com.akira.island.ui.GroupToggle
import com.akira.island.ui.Page
import com.akira.island.ui.Pos
import com.akira.island.ui.Tile
import com.akira.island.ui.Ui

@Composable
fun LyricsScreen(onBack: () -> Unit) {
    val s by SettingsRepo.state.collectAsState()
    Page(tr("Текст песен", "Lyrics", "歌词"), onBack) {
        Group {
            GroupToggle(Pos.Single, Icons.Rounded.LibraryMusic, tr("Текст песен", "Lyrics", "歌词"),
                tr("Строка песни в раскрытом плеере заливается белым по мере пения", "The current line in the expanded player fills with white as it's sung", "展开的播放器中，当前歌词行会随着演唱逐渐变白"),
                s.lyricsEnabled, color = Tile.Pink) { v -> SettingsRepo.update { copy(lyricsEnabled = v) } }
        }
        Text(
            tr(
                "Текст ищется по названию, исполнителю и длительности трека: сначала на LRCLIB (lrclib.net), " +
                    "потом на NetEase — там много русской музыки. Если синхронного текста нет нигде, строки обычного текста " +
                    "раскладываются по длине песни. Пока идёт поиск, в плеере написано «Ищу текст песни…», " +
                    "если ничего не нашлось — «Текст песни не найден». На сервер уходят только название и исполнитель. " +
                    "Работает с любым плеером, который показывает уведомление с управлением: Spotify, YouTube Music, Яндекс Музыка, VK и т.д.",
                "Lyrics are looked up by title, artist and track length: first on LRCLIB (lrclib.net), then on NetEase, " +
                    "which has a lot of Russian music. If there are no synced lyrics anywhere, plain lyrics are spread over " +
                    "the length of the song. While searching, the player says “Looking for lyrics…”, and if nothing is found —" +
                    " “No lyrics found”. Only the title and artist are sent to the server. Works with any player that shows a " +
                    "notification with controls: Spotify, YouTube Music, Yandex Music, VK and others.",
                "歌词会按歌名、歌手和歌曲时长查找：先在 LRCLIB (lrclib.net) 上找，然后到网易云音乐——那里有很多俄语音乐。如果哪里都没有同步歌词，就会把普通歌词按歌曲时长平均分布。搜索期间，播放器显示“正在查找歌词…”，如果什么都没找到——显示“未找到歌词”。只有歌名和歌手会发送到服务器。适用于任何带控制通知的播放器：Spotify、YouTube Music、Yandex Music、VK 等。",
            ),
            color = Ui.Sub,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Ui.Card).padding(20.dp),
        )
    }
}
