package com.akira.island.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Downloading
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.HourglassEmpty
import androidx.compose.material.icons.rounded.KeyboardVoice
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.OfflineBolt
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.akira.island.core.tr
import com.akira.island.data.IslandSettings
import com.akira.island.data.SettingsRepo
import com.akira.island.ui.Group
import com.akira.island.ui.GroupToggle
import com.akira.island.ui.IconAction
import com.akira.island.ui.Page
import com.akira.island.ui.Pos
import com.akira.island.ui.SectionHeader
import com.akira.island.ui.Tile

/** «Динамические карточки»: что остров показывает, пока это идёт, — по разделам. */
@Composable
fun CardsScreen(onBack: () -> Unit, onInstruction: () -> Unit) {
    val s by SettingsRepo.state.collectAsState()
    fun set(block: IslandSettings.() -> IslandSettings) = SettingsRepo.update(block)

    Page(tr("Динамические карточки", "Dynamic cards", "动态卡片"), onBack,
        action = { IconAction(Icons.Rounded.Lightbulb, tr("Инструкция", "Instructions", "使用说明"), onInstruction) }) {
        SectionHeader(tr("Музыка и звонки", "Music and calls", "音乐和通话"))
        Group {
            GroupToggle(Pos.First, Icons.Outlined.PlayCircle, tr("Управление проигрывателем", "Player controls", "播放器控制"),
                tr("Когда играет музыка и плеер свёрнут", "When music is playing and the player is in the background", "音乐播放且播放器在后台时"),
                s.cardMedia, color = Tile.Pink) { set { copy(cardMedia = it) } }
            GroupToggle(Pos.Last, Icons.Rounded.Call, tr("Звонки", "Calls", "通话"),
                tr("Входящий вызов с кнопками ответа и время разговора", "Incoming calls with answer buttons, and the call time", "带接听按钮的来电界面和通话时长"),
                s.cardCall, color = Tile.Green) { set { copy(cardCall = it) } }
        }

        SectionHeader(tr("Таймеры и будильник", "Timers and alarm", "计时器和闹钟"))
        Group {
            GroupToggle(Pos.First, Icons.Rounded.HourglassEmpty, tr("Таймер и секундомер", "Timer and stopwatch", "计时器和秒表"),
                tr("Таймер и секундомер «Часов» в фоне — даже если их уведомления выключены",
                    "Clock's timer and stopwatch in the background — even with its notifications off",
                    "“时钟”的计时器和秒表在后台时也能显示——即使其通知已关闭"),
                s.cardTimer, color = Tile.Orange) { set { copy(cardTimer = it) } }
            GroupToggle(Pos.Middle, Icons.Rounded.TouchApp, tr("Кнопки для «Часов»", "Clock buttons", "“时钟”按钮"),
                tr("Пауза и сброс в острове нажимают кнопки самих «Часов». Выключено — просто открывают «Часы»",
                    "Pause and reset in the island press Clock's own buttons. Off — they just open Clock",
                    "灵动岛中的暂停和重置会点击“时钟”自己的按钮。关闭后——仅打开“时钟”"),
                s.clockAutoTap, color = Tile.Orange) { set { copy(clockAutoTap = it) } }
            GroupToggle(Pos.Middle, Icons.Rounded.KeyboardVoice, tr("Таймер от помощника", "Timer from assistant", "助手设置的计时器"),
                tr("«Поставь таймер на 5 минут» от помощника или виджета можно отдать острову",
                    "“Set a timer for 5 minutes” from an assistant or widget can go to the island",
                    "通过助手或小组件发出的“设置 5 分钟计时器”可以交给灵动岛"),
                s.timerFromAssistant, color = Tile.Pink) { set { copy(timerFromAssistant = it) } }
            GroupToggle(Pos.Last, Icons.Rounded.Bedtime, tr("Будильник", "Alarm", "闹钟"),
                tr("За 12 часов до будильника — время подъёма и циферблат сна, как на iPhone",
                    "12 hours before an alarm — the wake-up time and a sleep dial, like on iPhone",
                    "闹钟响起前 12 小时——显示起床时间和睡眠表盘，如同 iPhone"),
                s.cardAlarm, color = Tile.Indigo) { set { copy(cardAlarm = it) } }
        }

        SectionHeader(tr("Система", "System", "系统"))
        Group {
            GroupToggle(Pos.First, Icons.Rounded.FlashlightOn, tr("Управление вспышкой", "Flashlight controls", "手电筒控制"),
                tr("Когда включён фонарик", "When the flashlight is on", "手电筒开启时"),
                s.cardTorch, color = Tile.Yellow) { set { copy(cardTorch = it) } }
            GroupToggle(Pos.Middle, Icons.Rounded.OfflineBolt, tr("Индикатор зарядки", "Charging indicator", "充电指示"),
                tr("Когда устройство заряжается", "When the device is charging", "设备充电时"),
                s.cardCharging, color = Tile.Green) { set { copy(cardCharging = it) } }
            GroupToggle(Pos.Last, Icons.Rounded.Downloading, tr("Индикатор прогресса", "Progress indicator", "进度指示"),
                tr("Загрузки и отправка в Google Play, Telegram и других приложениях", "Downloads and uploads in Google Play, Telegram and other apps", "Google Play、Telegram 等应用中的下载和上传"),
                s.cardProgress, color = Tile.Teal) { set { copy(cardProgress = it) } }
        }

        SectionHeader(tr("В дороге", "On the road", "出行"))
        GroupToggle(Pos.Single, Icons.Rounded.Navigation, tr("Навигация, такси и доставка", "Navigation, taxi and delivery", "导航、打车和外卖"),
            tr("Google и Яндекс Карты, Навигатор, 2ГИС, Яндекс Go, Uber и другие — расстояние и время в капсуле, подробности в раскрытом виде",
                "Google and Yandex Maps, Navigator, 2GIS, Yandex Go, Uber and others — distance and time in the capsule, details when expanded",
                "Google 地图、Yandex 地图、导航、2GIS、Yandex Go、Uber 等——胶囊中显示距离和时间，展开后显示详情"),
            s.cardLive, color = Tile.Teal) { set { copy(cardLive = it) } }

        SectionHeader(tr("Сюрпризы", "Surprises", "惊喜"))
        GroupToggle(Pos.Single, Icons.Rounded.AutoAwesome, tr("Пасхалки", "Easter eggs", "彩蛋"),
            tr("Одну особенную песню остров узнаёт и устраивает для неё маленькое шоу в такт музыке. Какую — попробуйте угадать",
                "The island recognizes one special song and puts on a little show to its beat. Which one? Try to guess",
                "灵动岛能识别一首特别的歌，并随着节拍表演一段小秀。是哪首？猜猜看"),
            s.easterEggs, color = Tile.Red) { set { copy(easterEggs = it) } }
    }
}
