package com.akira.island.core

import android.content.res.Resources
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.ui.platform.LocalConfiguration
import com.akira.island.data.AppLanguage
import com.akira.island.data.SettingsRepo
import java.util.Locale

/** Язык интерфейса: русский, английский или китайский (упрощённый). */
enum class LangCode { RU, EN, ZH }

/**
 * Язык приложения и острова: русский, английский или китайский. «Как в системе» — русский, если телефон на русском,
 * китайский, если на китайском, иначе английский. Строки пишутся тройкой прямо в коде: tr("Зарядка", "Charging", "充电").
 */
object Lang {
    val code: LangCode
        get() = when (SettingsRepo.current.language) {
            AppLanguage.EN -> LangCode.EN
            AppLanguage.RU -> LangCode.RU
            AppLanguage.ZH -> LangCode.ZH
            AppLanguage.SYSTEM -> when (systemLanguage()) {
                "ru" -> LangCode.RU
                "zh" -> LangCode.ZH
                else -> LangCode.EN
            }
        }

    val ru: Boolean get() = code == LangCode.RU
    val en: Boolean get() = code == LangCode.EN
    val zh: Boolean get() = code == LangCode.ZH

    /** Для дат: «пятница, 24 октября», «Friday, October 24» или «10月24日 星期五» */
    val locale: Locale
        get() = when (code) {
            LangCode.EN -> Locale.ENGLISH
            LangCode.RU -> Locale.forLanguageTag("ru")
            LangCode.ZH -> Locale.SIMPLIFIED_CHINESE
        }

    private fun systemLanguage(): String =
        runCatching { Resources.getSystem().configuration.locales[0].language }.getOrNull() ?: Locale.getDefault().language
}

/** Строка на текущем языке. Если китайский перевод не задан — берётся английский. */
fun tr(ru: String, en: String, zh: String = en): String = when (Lang.code) {
    LangCode.RU -> ru
    LangCode.EN -> en
    LangCode.ZH -> zh
}

/**
 * Сменили язык (в настройках или в системе) — всё внутри рисуется заново уже на новом языке.
 * Состояние снаружи (открытая вкладка и экран) остаётся.
 */
@Composable
fun LangScope(content: @Composable () -> Unit) {
    val s by SettingsRepo.state.collectAsState()
    // Язык системы меняется вместе с конфигурацией — чтение подписывает на неё
    LocalConfiguration.current
    key(s.language, Lang.code) { content() }
}
